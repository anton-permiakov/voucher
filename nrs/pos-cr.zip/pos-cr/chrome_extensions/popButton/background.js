let tabLoaded, timerId;

chrome.runtime.onMessage.addListener(function (request, sender, sendResponse) {
  chrome.tabs.query(
    {
      active: true, // Select active tabs
      lastFocusedWindow: true, // In the current window
    },
    function (array_of_Tabs) {
      tabs = array_of_Tabs;
      for (var t = tabs.length - 1; t >= 0; t--) {
        chrome.tabs.remove(tabs[t].id, function () {});
      }
    }
  );
});

chrome.webNavigation.onErrorOccurred.addListener(function (details) {
  if (details.frameId === 0 && details.error !== "net::ERR_ABORTED") {
    chrome.tabs.update(details.tabId, {
      url:
        "http://localhost/errors/index.html?error=" +
        encodeURIComponent(details.error),
    });

    // chrome.tabs.remove(details.tabId, () => {
    //   clearTimeout(timerId);
    // });

    tabLoaded = 0;
  }
});

chrome.webNavigation.onCommitted.addListener((data) => {
  if(data.frameId === 0) {
    console.log('committed', data);
    clearTimeout(timerId);
    tabLoaded = 0;
    fetch('http://localhost/page-loaded');
  }
});

chrome.tabs.onCreated.addListener((data) => {
  console.log('tabCreated', data);

  timerId = setTimeout(() => {
    console.log('attempt to redirect', `tabLoaded=${tabLoaded}`);      
    if(!tabLoaded) {        
      tabLoaded = 0;
      chrome.tabs.update(data.tabId, {
        url: "http://localhost/errors/index.html?error=",
      }); 
    }     
  }, 3000);
});
