#!/bin/bash

DIR="$( cd "$( dirname "$0" )"; pwd )"	#abs path
BACKEND=$( dirname  $DIR )/backend
DIAG="$BACKEND"/src/diag
MYBIN=$( dirname $( dirname  $DIR ))/bin

dir0="$(dirname "$0")";

source "/etc/idt/install/idtrs-cr-tools.idtrs"

IFS=' ' read -r CASHIER TOK AGENT SSOTOKEN URL

if [ "x$CASHIER" == "x" ] ; then
  CASHIER="testprofile"
fi

if [ "x$TOK" == "x" ] ; then
  TOK="0"
fi


pref_path="$HOME/.config/google-chrome/Default/Preferences";
datadir_path="$HOME/$CASHIER";

BRPCFG='/etc/idt/brssoportal.txt'
#BRPORTAL='https://boss.idt.net/debit/2.0/bossrevolution/retailers/account/login.aspx'
#BRPORTAL='https://boss.idt.net/services/retailers/login/%BRACCT%'
BRPORTAL=$URL
if [ -f "$BRPCFG" ] ; then
	T=`head -1 "$BRPCFG"`
	if [ "$T" != "" ] ; then
		BRPORTAL="$T"
	fi
fi


if [ "$AGENT" != '-' ] ; then
  FINALURL="$BRPORTAL?token=$SSOTOKEN&agentpin=$AGENT";
else
  FINALURL="$BRPORTAL?token=$SSOTOKEN";
fi

#google-chrome "$FINALURL"
google-chrome "http://werwerwerytru.com"

exit 0

echo BR Portal - Launching datadir=$datadir_path URL=$FINALURL > $LOGDIR/launch_ssobrportal.log


if [ -f /etc/idt/virtualelmer ] ; then
  echo "MYBIN is $MYBIN" >> $LOGDIR/launch_brssoportal.log
  MSG="url:$TOK:$FINALURL"
  echo "Sending wss message $MSG" >> $LOGDIR/launch_brssoportal.log
  echo "$MSG" | $MYBIN/wssend 'localhost:8034/publish'
  exit 0;
fi

# clear out plugin status

GET http://localhost/api/checkplugin/clear

# now launch

nohup $dir0/clean-chrome.sh --prefs="$pref_path" --kiosk-old-keyboard \
	--user_prefs="${datadir_path}/Default/Preferences" \
	-- \
	--user-data-dir="$datadir_path" \
	--disable-infobars --disable-session-crashed-bubble \
	"$FINALURL" \
	>> $LOGDIR/launch_ssobrportal.log 2>&1 &

PID=$!
#
# setup background job to kill browser if it dies but stop checking if main process exists
# also tell it to check our plugin status
#
$INSTDIR/pos-cr/tools/kill-dead-browser.sh "$PID" "yes" 30 &

#remove downloads from previous launches
rm ~/Downloads/*

exit 0
