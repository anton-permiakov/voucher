<?php
chdir("../../../backend");
require_once 'vendor/autoload.php' ;
\Slim\Slim::registerAutoLoader() ;
$absPath = false;
require_once 'src/config.php' ;

$app = new \Slim\Slim(
           array(
             'debug'=>true
            ,'log.level' => \Slim\Log::DEBUG
            )
         ) ;

require_once Config::CFG_COMMON_DIR . "/n2po_curl.php" ;
require_once Config::CFG_COMMON_DIR . "/n2po_crypt.php" ;

require_once 'src/LazyLoad.php' ;
require_once 'src/authlib.php';
require_once 'src/spoollib.php';

require_once 'src/session.php' ;
require_once 'src/base.php' ;
require_once 'src/requestbase.php' ;

require_once 'src/receipt_utils.php' ;

require_once 'src/autoload.php' ;

// ...allow all CORS preflight requests
$app->options('/(:name+)', function($name) use($app) {
  $app->response->headers->set('Access-Control-Allow-Origin','*');
  $app->response->headers->set('Access-Control-Allow-Headers','*');
  $app->response->headers->set('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS') ;
  }) ;

// ...allow CORS on all actual requests
$app->response->headers->set('Access-Control-Allow-Origin','*');
$app->response->headers->set('Access-Control-Allow-Headers','*');
$app->response->headers->set('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS') ;



/*-------------------------------------------------------*
 *--
 *--  routing
 *--
 *-------------------------------------------------------*/
//$app->get ('/ping/:string'                                                             , new Ping($app))                                                                       ->name('ping') ;
$app->get   ('/ping/:string'                                                             , new LazyLoad($app , 'src/ping.php'            , 'Ping' ))                             ->name('ping') ;

/*-------------------------------------------------------*
 *--  auth
 *-------------------------------------------------------*/
$app->post  ('/authenticate'                                                             , new LazyLoad($app , 'src/pinauth.php'         , 'PinAuth'))                           ->name('authenticate') ;
$app->post  ('/passwordauthentication'                                                   , new LazyLoad($app , 'src/passwordauth.php'    , 'PasswordAuth'))                      ->name('passwordauth') ;
$app->get   ('/validate/:tok'                                                            , new LazyLoad($app , 'src/token_validator.php' , 'TokenValidator'))                    ->name('validate') ;
$app->get   ('/logout/:tok'                                                              , new LazyLoad($app , 'src/logout.php'          , 'Logout'))                            ->name('logout') ;

/*-------------------------------------------------------*
 *--  configuration
 *-------------------------------------------------------*/
$app->get   ('/logins'                                                                   , new LazyLoad($app , 'src/logins.php'          , 'SL_FetchAll'))                       ->name('logins') ;
$app->get   ('/departments/:tok'                                                         , new LazyLoad($app , ''                        , 'Departments_FetchDepartments'))      ->name('departments') ;
$app->get   ('/adconfig'                                                                 , new LazyLoad($app , ''                        , 'Store_AdConfig'))                    ->name('getadconfig') ;
$app->get   ('/metaconfig'                                                               , new LazyLoad($app , ''                        , 'MC_Fetch'))                          ->name('getmetaconfig') ;
$app->get   ('/logo'                                                                     , new LazyLoad($app , ''                        , 'MC_FetchLogo'))                      ->name('fetchstorelogo') ;
$app->post  ('/getnewcerts'                                                              , new LazyLoad($app , 'src/getnewcerts.php'     , 'Certs_GetNew'))                       ->name('getnewcerts') ;
/*-------------------------------------------------------*
 *--  session stuff
 *-------------------------------------------------------*/
// ...a session is automatically created and bound to a token at authentication time
//    the following two methods allow user to init & finalize the cash drawer
$app->post  ('/sessions/:tok/cashin'                                                     , new LazyLoad($app , ''                        , 'Session_Cashin'))                    ->name('cashin') ;
$app->get   ('/sessions/:tok/stats(/:session)'                                           , new LazyLoad($app , ''                        , 'Session_Stats'))                     ->name('getsessionstats') ;
$app->post  ('/sessions/:tok/fetch(/:drange)'                                            , new LazyLoad($app , ''                        , 'Session_fetchall'))                  ->name('fectsessions') ;
$app->post  ('/sessions/:tok/close'                                                      , new LazyLoad($app , ''                        , 'Session_Close'))                     ->name('close') ;
$app->post  ('/sessions/:tok/delete'                                                     , new LazyLoad($app , ''                        , 'Session_Delete'))                    ->name('delete') ;
$app->get   ('/sessions/:tok/fetch(/:drange)'                                            , new LazyLoad($app , ''                        , 'Session_FetchRange'))                ->name('fetchsessionrange') ;
$app->get   ('/sessions/:tok/summary(/:session)'                                         , new LazyLoad($app , ''                        , 'Session_Summary'))                   ->name('getsessionsummary') ;
$app->get   ('/sessions/fetchlast'                                                       , new LazyLoad($app , ''                        , 'Session_FetchLast'))                 ->name('getlastunclosedsession') ;
/*-------------------------------------------------------*
 *--  store stuff (data pulls                                                            , basically)
 *-------------------------------------------------------*/
$app->get   ('/stores/:tok/info'                                                         , new LazyLoad($app , ''                        , 'Store_Info'))                        ->name('getstoreinfo') ;
//return terminal info without requiring token - for marketing team
$app->get   ('/stores/terminalinfo'                                                      , new LazyLoad($app , ''                        , 'Store_TerminalInfo'))                ->name('getterminalinfo') ;
$app->post   ('/stores/:tok/ecommercestats'                                              , new LazyLoad($app , ''                        , 'Store_EcommerceStats'))              ->name('getecommercestorestats') ;
$app->get   ('/stores/:tok/stats/:drange'                                                , new LazyLoad($app , ''                        , 'Store_Stats'))                       ->name('getstorestats') ;
$app->get   ('/stores/:tok/printstats/:drange(/:queue)'                                  , new LazyLoad($app , ''                        , 'Store_PrintStats'))                  ->name('printstorestats') ;
$app->get   ('/stores/:tok/printshiftstats(/:detail)(/:queue)'                           , new LazyLoad($app , ''                        , 'Store_PrintShiftStats'))             ->name('printstoreshiftstats') ;
$app->get   ('/stores/:tok/stats/cardtype/:drange'                                       , new LazyLoad($app , ''                        , 'Store_CardTypeStats'))               ->name('getstorecardstats') ;
$app->get   ('/stores/:tok/printstats/cc/cardtype/:drange(/:queue)'                      , new LazyLoad($app , ''                        , 'Store_PrintCardTypeStats'))       ->name('printstorecardstats') ;
$app->get   ('/stores/:tok/printstats/cc/batchreport/:drange(/:queue)'        , new LazyLoad($app , ''                        , 'Store_PrintBatchReport'))       ->name('printstorebatchreport') ;
$app->get   ('/stores/:tok/getpreviousbatch/:closed'                                     , new LazyLoad($app , ''                        , 'Store_GetPreviousBatch'))         ->name('getpreviousbatch') ;
$app->get   ('/stores/gtag_id'                                                           , new LazyLoad($app , ''                        , 'Store_Getgtag'))                        ->name('getgtag') ;
/*-------------------------------------------------------*
 *--  basket stuff
 *-------------------------------------------------------*/
$app->get   ('/baskets/:tok/all'                                                         , new LazyLoad($app , 'src/basket.php'          , 'B_FetchAll'))                        ->name('getbaskets') ;
$app->get   ('/baskets/:tok/session'                                                     , new LazyLoad($app , 'src/basket.php'          , 'B_FetchSession'))                    ->name('getsessionbaskets') ;
$app->get   ('/baskets/:tok/create'                                                      , new LazyLoad($app , 'src/basket.php'          , 'B_Create'))                          ->name('createbasket') ;
$app->post  ('/baskets/:tok/:basket/add'                                                 , new LazyLoad($app , 'src/basket.php'          , 'B_AddItem'))                         ->name('addtobasket') ;
$app->post  ('/baskets/:tok/:basket/multiadd'                                            , new LazyLoad($app , 'src/basket.php'          , 'B_AddItems'))                        ->name('multiaddtobasket') ;
$app->get   ('/baskets/:tok/:basket/:item/void'                                          , new LazyLoad($app , 'src/basket.php'          , 'B_VoidItem'))                        ->name('voidbasketitem') ;
$app->post  ('/baskets/:tok/:basket/:item/update'                                        , new LazyLoad($app , 'src/basket.php'          , 'B_UpdateItem'))                      ->name('updatebasketitem') ;
$app->post  ('/baskets/:tok/:basket/addpay'                                              , new LazyLoad($app , 'src/basket.php'          , 'B_AddPayment'))                      ->name('addbasketpayment') ;
$app->get   ('/baskets/:tok/:basket/pause'                                               , new LazyLoad($app , 'src/basket.php'          , 'B_Pause'))                           ->name('pausebasket') ;
$app->get   ('/baskets/:tok/:basket/resume'                                              , new LazyLoad($app , 'src/basket.php'          , 'B_Resume'))                          ->name('resumebasket') ;
$app->post  ('/baskets/:tok/:basket/abandon'                                             , new LazyLoad($app , 'src/basket.php'          , 'B_Abandon'))                         ->name('abandonbasket') ;
$app->post  ('/baskets/:tok/:basket/close'                                               , new LazyLoad($app , 'src/basket.php'          , 'B_Close'))                           ->name('closebasket') ;
$app->post  ('/baskets/:tok/:basket/transfer'                                            , new LazyLoad($app , 'src/basket.php'          , 'B_Transfer'))                        ->name('transferbasket') ;
$app->get   ('/baskets/:tok/:basket/print(/:force)(/:queue)'                             , new LazyLoad($app , 'src/basket.php'          , 'B_Print'))                           ->name('printbasket') ;
$app->get   ('/baskets/:tok/:basket/render'                                      , new LazyLoad($app , 'src/basket.php'          , 'B_Print'))                           ->name('renderbasket') ;
$app->post  ('/baskets/:tok/:basket/setloyalty'                                          , new LazyLoad($app , 'src/basket.php'          , 'B_SetLoyalty'))                      ->name('basketsetloyalty') ;
$app->get   ('/baskets/:tok/:basket/bossquery'                                           , new LazyLoad($app , 'src/basket.php'          , 'B_BossQuery'))                       ->name('basketbossquery') ;
$app->post  ('/baskets/:tok/:basket/bossrecharge'                                        , new LazyLoad($app , 'src/basket.php'          , 'B_BossRecharge'))                    ->name('basketbossrecharge') ;
$app->get   ('/baskets/:tok/:basket/bosscreate'                                          , new LazyLoad($app , 'src/basket.php'          , 'B_BossCreate'))                      ->name('basketbosscreate') ;
$app->post  ('/baskets/:tok/dataasbasket/print(/:queue)'                                 , new LazyLoad($app , 'src/basket.php'          , 'B_PrintData'))                           ->name('printdataasbasket') ;
$app->post  ('/baskets/:tok/dataasbasket/render'                                         , new LazyLoad($app , 'src/basket.php'          , 'B_PrintData'))                           ->name('renderdataasbasket') ;
$app->post  ('/baskets/:tok/:basket/sms'                                                 , new LazyLoad($app , 'src/basket.php'          , 'B_SMSReceipt'))                           ->name('sendsms') ;

/*-------------------------------------------------------*
 *--  drops
 *-------------------------------------------------------*/
$app->get   ('/drops/:tok/all'                                                           , new LazyLoad($app , 'src/drop.php'            , 'D_FetchAll'))                        ->name('getdrops') ;
$app->get   ('/drops/:tok/session'                                                       , new LazyLoad($app , 'src/drop.php'            , 'D_FetchSession'))                    ->name('getsessiondrops') ;
$app->post  ('/drops/:tok/create'                                                        , new LazyLoad($app , 'src/drop.php'            , 'D_Create'))                          ->name('createdrop') ;
$app->get   ('/drops/:tok/:drop/print(/:queue)'                                          , new LazyLoad($app , 'src/drop.php'            , 'D_Print'))                           ->name('printdrop') ;

/*-------------------------------------------------------*
 *--  paypod
 *-------------------------------------------------------*/
$app->get   ('/paypod/gettoken'                                                          , new LazyLoad($app, ''                         , 'Paypod_Gettoken'))->name('getpaypodtoken');
$app->get   ('/paypod/:auth/getsystemstatus'                                             , new LazyLoad($app, ''                         , 'Paypod_Getsystemstatus'))->name('getpaypodsystemstatus');
$app->post  ('/paypod/:auth/transaction'                                                 , new LazyLoad($app, ''                         , 'Paypod_Transaction'))->name('paypodtransaction');
$app->get   ('/paypod/:auth/transactionstatus/:id'                                       , new LazyLoad($app, ''                         , 'Paypod_TransactionStatus'))->name('paypodtransactionstatus');
$app->get   ('/paypod/:auth/cancel/:id'                                                  , new LazyLoad($app, ''                         , 'Paypod_Cancel'))->name('paypodcanceltransaction');
$app->get   ('/paypod/:auth/paymentdevices'                                              , new LazyLoad($app, ''                         , 'Paypod_Getdevices'))->name('getpaypoddevices');
$app->get   ('/paypod/:auth/end/:id'                                                     , new LazyLoad($app, ''                         , 'Paypod_End'))->name('paypodendtransaction');
$app->get   ('/paypod/:auth/getmessages'                                                 , new LazyLoad($app, ''                         , 'Paypod_Getmessages'))->name('getpaypodmessages');
$app->get   ('/paypod/:auth/currenttransaction'                                          , new LazyLoad($app, ''                         , 'Paypod_CurrentTransaction'))->name('paypodcurrenttransaction');
$app->post  ('/paypod/:auth/fill'                                                        , new LazyLoad($app, ''                         , 'Paypod_Fill'))->name('paypodfill');
$app->post  ('/paypod/:auth/adjustcash'                                                  , new LazyLoad($app, ''                         , 'Paypod_AdjustCash'))->name('paypodadjustcash');
$app->get   ('/paypod/startpolling'                                                      , new LazyLoad($app, ''                         , 'Paypod_StartPolling'))->name('startpolling');

/*-------------------------------------------------------*
 *--  payouts
 *-------------------------------------------------------*/
$app->get   ('/payouts/:tok/all'                                                         , new LazyLoad($app , 'src/payout.php'          , 'PO_FetchAll'))                       ->name('getpayouts') ;
$app->get   ('/payouts/:tok/session'                                                     , new LazyLoad($app , 'src/payout.php'          , 'PO_FetchSession'))                   ->name('getsessionpayouts') ;
$app->post  ('/payouts/:tok/create'                                                      , new LazyLoad($app , 'src/payout.php'          , 'PO_Create'))                         ->name('createpayout') ;
$app->get   ('/payouts/:tok/:payout/print(/:queue)'                                      , new LazyLoad($app , 'src/payout.php'          , 'PO_Print'))                          ->name('printpayout') ;

/*-------------------------------------------------------*
 *--  vendors
 *-------------------------------------------------------*/
$app->get   ('/vendors/:tok/all'                                                         , new LazyLoad($app , 'src/vendor.php'          , 'V_FetchAll'))                        ->name('getvendors') ;
$app->post  ('/vendors/:tok/add'                                                         , new LazyLoad($app , 'src/vendor.php'          , 'V_Add'))                             ->name('addvendor') ;
$app->post  ('/vendors/:tok/post'                                                        , new LazyLoad($app , 'src/vendor.php'          , 'V_Post'))                            ->name('postvendor') ;
$app->post  ('/vendors/:tok/:vendor/update'                                              , new LazyLoad($app , 'src/vendor.php'          , 'V_Update'))                          ->name('updvendor') ;
$app->post  ('/vendors/:tok/:vendor/toggleExpired'                                       , new LazyLoad($app , 'src/vendor.php'          , 'V_ToggleExpired'))                   ->name('togglevendorexpired') ;
$app->post  ('/vendors/:tok/:vendor/delete'                                              , new LazyLoad($app , 'src/vendor.php'          , 'V_Delete'))                          ->name('delvendor') ;
$app->get   ('/vendors/:tok/:vendor/payouts'                                             , new LazyLoad($app , 'src/vendor.php'          , 'V_FetchPayouts'))                    ->name('fetchvendorpayouts') ;
$app->post  ('/vendors/:tok/payoutsdateRange'                                            , new LazyLoad($app , 'src/vendor.php'          , 'V_FetchPayoutsForDateRange'))        ->name('fetchVendorPayoutsWithDateRange') ;
$app->get   ('/vendors/:tok/:merchtoken/:store_id/polist'                                , new LazyLoad($app , 'src/vendor.php'          , 'V_FetchPurchaseOrders'))             ->name('fetchVendorPurchaseOrders') ;
$app->post  ('/vendors/:tok/print'                                                       , new LazyLoad($app , 'src/vendor.php'          , 'V_PrintVendorDetail'))               ->name('printvendordetail') ;

/*-------------------------------------------------------*
 *--  users
 *-------------------------------------------------------*/
$app->get   ('/users/:tok/current'                                                       , new LazyLoad($app , 'src/users.php'           , 'U_FetchCurrent'))                    ->name('getcuruser') ;
$app->get   ('/users/:tok/all'                                                           , new LazyLoad($app , 'src/users.php'           , 'U_FetchAll'))                        ->name('getusers') ;
$app->post  ('/users/:tok/add'                                                           , new LazyLoad($app , 'src/users.php'           , 'U_Add'))                             ->name('adduser') ;
$app->post  ('/users/:tok/:uid/toggleExpired'                                            , new LazyLoad($app , 'src/users.php'           , 'U_ToggleExpired'))                   ->name('toggleuserexpired') ;
$app->post  ('/users/:tok/changePin'                                                     , new LazyLoad($app , 'src/users.php'           , 'U_ChangePin'))                       ->name('changePin') ;
$app->get   ('/user/:tok/:uid'                                                           , new LazyLoad($app , 'src/users.php'           , 'U_FetchDetail'))                     ->name('fetchDetail') ;

/*-------------------------------------------------------*
 *--  barcode lookups and printing
 *-------------------------------------------------------*/
$app->get   ('/barcodes/:tok/:upc'                                                       , new LazyLoad($app , 'src/pricebook.php'       , 'PB_GenerateUpcA'))                   ->name('genupca') ;

/*-------------------------------------------------------*
 *--  pricebook
 *-------------------------------------------------------*/
//$app->get   ('/pricebooks/:tok/:pbname'                                                  , new LazyLoad($app , 'src/pricebook.php'       , 'PB_FetchAll'))                       ->name('fetchpbitems') ;
//$app->get   ('/pricebooks/:tok/:pbname/detail/:upc'                                      , new LazyLoad($app , 'src/pricebook.php'       , 'PB_FetchItem'))                      ->name('fetchpbitem') ;
$app->post  ('/pricebooks/:tok/:pbname/add'                                              , new LazyLoad($app , 'src/pricebook.php'       , 'PB_AddItem'))                        ->name('addpbitem') ;
//$app->post  ('/pricebooks/:tok/:pbname/update'                                           , new LazyLoad($app , 'src/pricebook.php'       , 'PB_UpdateItem'))                     ->name('updpbitem') ;
//$app->get   ('/pricebooks/:tok/:pbname/fetchless'                                        , new LazyLoad($app , ''                        , 'Pricebook_FetchLessFields'))         ->name('lessfieldpbitem') ;

/*-------------------------------------------------------*
 *--  master price list
 *-------------------------------------------------------*/
$app->post  ('/mpl/:tok/add'                                                             , new LazyLoad($app , 'src/mpl.php'             , 'MPL_AddItem'))                       ->name('addmplitem') ;
$app->post  ('/mpl/:tok/addprivate'                                                      , new LazyLoad($app , 'src/mpl.php'             , 'MPL_AddPrivateItem'))                ->name('addmplprivateitem') ;
$app->post  ('/mpl/:tok/:upc/updprivate'                                                 , new LazyLoad($app , 'src/mpl.php'             , 'MPL_UpdatePrivateItem'))             ->name('updmplprivateitem') ;
$app->get   ('/mpl/:tok/private'                                                         , new LazyLoad($app , 'src/mpl.php'             , 'MPL_FetchPrivateItems'))             ->name('fetchprivateitems') ;
$app->get   ('/mpl/:tok/:upc'                                                            , new LazyLoad($app , 'src/mpl.php'             , 'MPL_FetchMasterItem'))               ->name('fetchmasteritem') ;
$app->post  ('/mpl/:tok/deleteprivate'                                                   , new LazyLoad($app , 'src/mpl.php'             , 'MPL_DeletePrivateItem'))             ->name('deleteprivateitems') ;

/*-------------------------------------------------------*
 *--  pricebook items
 *-------------------------------------------------------*/
$app->get   ('/pbitems/:tok/:pbname'                                                     , new LazyLoad($app , ''                        , 'Pricebook_FetchPricebookItemList'))  ->name('fetchlistpbis') ;
$app->get   ('/pbitems/:tok/:pbname/private'                                             , new LazyLoad($app , ''                        , 'Pricebook_FetchPrivateItems'))       ->name('fetchprivatepbis') ;
$app->get   ('/pbitems/:tok/:pbname/fetchless'                                           , new LazyLoad($app , ''                        , 'Pricebook_FetchPricebookItemsLess')) ->name('fetchlesspbis') ;
$app->get   ('/pbitems/:tok/:pbname/masteritem/:upc'                                     , new LazyLoad($app , ''                        , 'Pricebook_FetchMasterItem'))         ->name('fetchmasterpbitem') ;
$app->get   ('/pbitems/:tok/:pbname/:upc/alias/:alias'                                                , new LazyLoad($app , ''              , 'Pricebook_FetchPricebookItemByUpc')) ->name('fetchpbibyalias') ;
$app->get   ('/pbitems/:tok/:pbname/:upc'                                                , new LazyLoad($app , ''                        , 'Pricebook_FetchPricebookItemByUpc')) ->name('fetchpbi') ;
$app->get   ('/pbitems/:tok/:pbname/filtered'                                                , new LazyLoad($app , ''                        , 'Pricebook_FetchPricebookItemByFilter')) ->name('fetchpbibyfilter') ;
$app->post  ('/pbitems/:tok/:pbname'                                                     , new LazyLoad($app , ''                        , 'Pricebook_PostPricebookItem'))       ->name('postpbi') ;
$app->post  ('/pbitems/:tok/:pbname/delete'                                              , new LazyLoad($app , ''                        , 'Pricebook_DeletePricebookItem'))     ->name('deletepbi') ;
$app->post  ('/pbitems/:tok/:pbname/private'                                             , new LazyLoad($app , ''                        , 'Pricebook_PostPrivatePBItem'))       ->name('postprivatepbi') ;
$app->post  ('/pbitems/:tok/:pbname/bulk'                                                , new LazyLoad($app , ''                        , 'Pricebook_PostBulkPBItem'))          ->name('postbulkpbi') ;

$app->get   ('/caching/:tok/pbitem'                                                    , new LazyLoad($app , ''                        , 'Pricebook_FetchRememberedLastItem')) ->name('fetchlastitem') ;
$app->post  ('/caching/:tok/pbitem'                                                     , new LazyLoad($app , ''                       , 'Pricebook_PostRememberLastItem'))       ->name('postlastitem') ;
$app->get ('/:tok/querysimplifiedplulist(/:organic(/:query))'                           , new LazyLoad($app, '', 'Pricebook_QuerySimplifiedPluList'))                  ->name('querysimplifiedplulist') ;
/*-------------------------------------------------------*
 *--  Modifiers
 *-------------------------------------------------------*/
$app->get ('/modifiers/:tok/modifierlist/:pricebook(/:filter)'                                                , new LazyLoad($app , ''                       , 'Modifier_FetchModifierList'))       ->name('fetchmodifierlist') ;
$app->get ('/modifiers/:tok/grouplist/:pricebook(/:filter)'                                                         , new LazyLoad($app , ''                       , 'Modifier_FetchGroupList'))       ->name('fetchGrouplist') ;
$app->get ('/modifiers/:tok/modifiergroups/:pricebook(/:filter)'                                                     , new LazyLoad($app , ''                       , 'Modifier_FetchModifierGroups'))       ->name('fetchmodifiergroups') ;
$app->post ('/modifiers/:tok/group/:pricebook'                                                     , new LazyLoad($app , ''                       , 'Modifier_UpdateModifierGroup'))       ->name('updatemodifiergroup') ;
$app->post ('/modifiers/:tok/groupid/:group/delete'                                                     , new LazyLoad($app , ''                       , 'Modifier_DeleteModifierGroup'))       ->name('deletemodifiergroup') ;
/*-------------------------------------------------------*
 *--  upc management
 *-------------------------------------------------------*/
$app->post  ('/upcmanager/fetchupcsupdates'                                              , new LazyLoad($app , ''                        , 'UpcManager_FetchUpcsUpdates'))       ->name('fetchupcsupdates') ;
$app->post  ('/upcmanager/saveupcsupdates'                                               , new LazyLoad($app , ''                        , 'UpcManager_SaveUpcsUpdates'))        ->name('saveupcsupdates') ;

/*-------------------------------------------------------*
 *--  printer management
  *-------------------------------------------------------*/
  $app->get   ('/printmanager/:tok/view'                                                   , new LazyLoad($app , ''                        , 'PrintManager_View'))                 ->name('printmanagerview') ;
  $app->post  ('/printmanager/:tok/delete(/:index)'                                          , new LazyLoad($app , ''                        , 'PrintManager_Delete'))               ->name('printmanagerdelete') ;
  $app->get   ('/printmanager/:tok/update'                                                 , new LazyLoad($app , ''                        , 'PrintManager_Update'))               ->name('printmanagerupdate') ;
  $app->post  ('/printmanager/:tok/edit'                                                   , new LazyLoad($app , ''                        , 'PrintManager_Edit'))                 ->name('printmanageredit') ;
  $app->post  ('/printmanager/:tok/insert'                                                 , new LazyLoad($app , ''                        , 'PrintManager_Insert'))               ->name('printmanagerinsert') ;
  $app->get   ('/printmanager/printtest/:queue'                                            , new LazyLoad($app , ''                        , 'PrintManager_Test'))                 ->name('printmanagertest') ;
/*-------------------------------------------------------*
 *--  terminal sync
 *-------------------------------------------------------*/
$app->post  ('/terminalsync/recordchangeset'                                             , new LazyLoad($app , ''                        , 'TerminalSync_RecordChangeSet'))      ->name('recordchangeset') ;
$app->post  ('/terminalsync/fetchchangeset'                                              , new LazyLoad($app , ''                        , 'TerminalSync_FetchChangeSet'))       ->name('fetchchangeset') ;
$app->post  ('/terminalsync/savechangeset'                                               , new LazyLoad($app , ''                        , 'TerminalSync_SaveChangeSet'))        ->name('savechangeset') ;
$app->get   ('/terminalsync/:tok/getsyncstatus'                                          , new LazyLoad($app , ''                        , 'TerminalSync_GetSyncStatus'))        ->name('getsyncstatus') ;
$app->get   ('/terminalsync/checklocalsyncstatus'                                        , new LazyLoad($app , ''                        , 'TerminalSync_CheckLocalSyncStatus')) ->name('checklocalsyncstatus') ;
$app->post  ('/terminalsync/:tok/synchdata/init'                                         , new LazyLoad($app , ''                        , 'TerminalSync_SynchDataInit'))        ->name('synchdatainit') ;
$app->post  ('/terminalsync/:tok/synchdata/done'                                         , new LazyLoad($app , ''                        , 'TerminalSync_SynchDataDone'))        ->name('synchdatadone') ;
$app->post  ('/terminalsync/:tok/setsyncstatus'                                          , new LazyLoad($app , ''                        , 'TerminalSync_SetSyncStatus'))        ->name('setsyncstatus') ;
$app->post  ('/terminalsync/backfill'                                                    , new LazyLoad($app , ''                        , 'TerminalSync_Backfill'))             ->name('backfill') ;
$app->post  ('/terminalsync/:tok/pcrhistory/backfill'                                    , new LazyLoad($app , ''                        , 'TerminalSync_PcrHistoryBackfill'))   ->name('pcrhistorybackfill') ;

$app->get   ('/p2p/termsyncpoke'                                                         , new LazyLoad($app , 'src/termsyncpoke.php'    , 'TermSyncPoke'))                      ->name('termsyncpoke') ; //tbd

/*-------------------------------------------------------*
 *--  promotions
 *-------------------------------------------------------*/
$app->get   ('/promotions/:tok/current/:viewoption'                                      , new LazyLoad($app , 'src/promotions.php'      , 'Promos_FetchCurrent'))               ->name('currentpromos') ;
$app->get   ('/promotions/:tok/detail/:promoId'                                          , new LazyLoad($app , 'src/promotions.php'      , 'Promos_FetchDetail'))                ->name('fetchpromodetail') ;
$app->get   ('/promotions/:tok/detail/type/:type/active/:active'          , new LazyLoad($app , ''      , 'Promos_FetchPromosByType'))                ->name('fetchpromosbytype') ;
$app->post  ('/promotions/:tok/add'                                                      , new LazyLoad($app , ''                        , 'Promos_PostStorePromos'))            ->name('addpromotionitem') ;
$app->post  ('/promotions/:tok/post'                                                     , new LazyLoad($app , ''                        , 'Promos_PostStorePromos'))            ->name('postpromotionitem') ;
$app->post  ('/promotions/:tok/sync/delete'                                              , new LazyLoad($app , ''                        , 'Promos_DeleteStorePromos'))          ->name('syncdeletepromotionitem') ;
$app->post  ('/promotions/:tok/delete'                                                   , new LazyLoad($app , 'src/promotions.php'      , 'Promos_Delete'))                     ->name('deletepromotionitem') ;
$app->post  ('/promotions/:tok/checkforexisting/:ts'                                         , new LazyLoad($app , 'src/promotions.php'      , 'Promos_CheckItem'))              ->name('checkinexistingpromotion') ;
$app->post  ('/promotions/:tok/upcs'                                                      , new LazyLoad($app , ''                        , 'Promos_UpdatePromoUpcs'))           ->name('addpromotionupcs') ;
$app->get   ('/promotions/fetchexternalpromos'                                           , new LazyLoad($app , ''                        , 'Promos_FetchExternalPromos'))        ->name('fetchexternalpromos') ;
$app->post  ('/promotions/saveexternalpromos'                                            , new LazyLoad($app , ''                        , 'Promos_SaveExternalPromos'))         ->name('saveexternalpromos') ;
$app->get   ('/promotions/:tok/count/:upc'                                               , new LazyLoad($app , 'src/promos/getnumpromos.class.php' , 'Promos_Getnumpromos'))     ->name('countpromos') ;

// ...fetch local & cloud bossrev promo usage (default is to fetch usage for all active promos - but one or more extpromoids may be specified explicitly)
$app->get   ('/promotions/:tok/usage/:loyuser/local(/:extpromoid+)'                      , new LazyLoad($app , null                      , 'Promos_FetchLocalUsage'))            ->name('fetchlocalpromousage') ;
$app->get   ('/promotions/:tok/usage/:loyuser/cloud(/:extpromoid+)'                      , new LazyLoad($app , null                      , 'Promos_FetchCloudUsage'))            ->name('fetchcloudpromousage') ;
$app->get('/benefits/:tok/customer/:brnumber', new LazyLoad($app, null, 'Customer_FetchBenefits'))
  ->name('fetchcustomerbenefits');
$app->post  ('/promotions/transmitaltriapromodata/:tok/:brnumber/:basketid'              , new LazyLoad($app , null                      , 'Promos_TransmitAltriaPromoData'))    ->name('transmitaltriapromodata') ;

/*-------------------------------------------------------*
 *--  coffee-clubs
 *-------------------------------------------------------*/
$app->get ('/coffee_clubs/:tok/:merchtoken/:storeid/get/:allorid', new LazyLoad($app, 'src/coffeeclubs/get_clubs.php', 'Coffeeclubs_Get'))->name('getcoffeeclubs');
$app->post('/coffee_clubs/:tok/:merchtoken/:storeid/upsert', new LazyLoad($app, 'src/coffeeclubs/upsert_club.php', 'Coffeeclubs_Upsert'))->name('upsertcoffeeclub');
$app->post('/coffee_clubs/:tok/:merchtoken/:storeid/delete', new LazyLoad($app, 'src/coffeeclubs/delete_club.php', 'Coffeeclubs_Delete'))->name('deletecoffeeclub');
$app->get('/coffee_clubs/redemptioncode/:redemptioncode', new LazyLoad($app, 'src/coffeeclubs/get_redemption.php', 'Redemption_Get'))->name('coffeeclubredemption');
$app->post('/coffee_clubs/:tok/:merchtoken/:storeid/debitstars/:basketid', new LazyLoad($app, 'src/coffeeclubs/debit_stars.php', 'CoffeeClubs_DebitStars'))->name('coffeedebitstars');
$app->post('/coffee_clubs/:tok/:merchtoken/:storeid/creditstars/:customer_phone/:basketid', new LazyLoad($app, 'src/coffeeclubs/credit_stars.php', 'CoffeeClubs_CreditStars'))->name('coffeecreditstars');
$app->get('/coffee_clubs/:tok/:merchtoken/images', new LazyLoad($app, 'src/coffeeclubs/fetch_club_images.php', 'CoffeeClubs_FetchClubImages'))->name('fetchclubimages');
$app->get('/coffee_clubs/:image', new LazyLoad($app, 'src/coffeeclubs/club_image.php', 'CoffeeClubs_ClubImage'))->name('clubimage');

/*-------------------------------------------------------*
 *--  points
 *-------------------------------------------------------*/
$app->get ('/points/:tok/get/:allorid', new LazyLoad($app, 'src/points/get_pointslevel.php', 'Pointslevel_Get'))->name('getpointslevel');
$app->post('/points/:tok/upsert/:id', new LazyLoad($app, 'src/points/upsert_pointslevel.php', 'Pointslevel_Upsert'))->name('upsertpointslevel');
$app->post('/points/:tok/delete/:id', new LazyLoad($app, 'src/points/delete_pointslevel.php', 'Pointslevel_Delete'))->name('deletepointslevel');
$app->get('/points/:tok/:redemptioncode', new LazyLoad($app, 'src/points/get_redemption.php', 'Redemption_Get'))->name('pointsredemption');
$app->post('/points/:tok/updatepoints', new LazyLoad($app, '', 'Points_UpdatePoints'))->name('updatepoints');

/*-------------------------------------------------------*
 *--  loyalty (clubs & points)
 *-------------------------------------------------------*/

$app->post('/loyalty/:tok/sendtokenbysms/:brnumber/:type/:id', new LazyLoad($app, 'src/loyalty/sendtokenbysms.class.php', 'Loyalty_SendTokenBySms'))->name('loyalty_sendtokenbysms');

/*-------------------------------------------------------*
 *--  rewards
 *-------------------------------------------------------*/
$app->post('/rewards/:tok/check(/:loyuser)', new LazyLoad($app, null, 'Rewards_Check'))->name('rewardsCheck') ;
$app->post('/rewards/:tok/convey(/:loyuser)', new LazyLoad($app, null, 'Rewards_Convey'))->name('rewardsConvey') ;
$app->post('/rewards/:tok/notifyprint', new LazyLoad($app, null, 'Rewards_NotifyPrint'))->name('rewardsNotifyPrint') ;

$app->get('/customer/:tok/lastpurchase/:loyuser', new LazyLoad($app, null, 'Customer_lastpurchase'))->name('customerLastPurchase') ;
$app->get('/customer/:tok/allpurchases/:loyuser', new LazyLoad($app, null, 'Customer_allpurchases'))->name('customerAllPurchases') ;
$app->get('/customer/:tok/allbaskets/:loyuser', new LazyLoad($app, null, 'Customer_allbaskets'))->name('customerAllBaskets') ;
$app->get('/customer/:tok/rewardsStats/:store_id/:loyuser', new LazyLoad($app, null, 'Customer_rewardsstats'))->name('customerRewardsStats') ;
$app->get('/customer/:tok/allbasketitems/:loyuser/:basket/:open_date', new LazyLoad($app, null, 'Customer_allbasketitems'))->name('customerAllBasketItems') ;
$app->post('/customer/:tok/consumerid/:consumerNumber', new LazyLoad($app, null, 'Customer_ConsumerId'))->name('customerconsumerid') ;

/*-------------------------------------------------------*
 *--  licensing
 *-------------------------------------------------------*/
 //tbd tok?
$app->post('/licensing/:tok/checklicense' , new LazyLoad($app , null , 'Licensing_CheckLicense'))->name('licensingCheckLicense') ;
$app->post('/licensing/:tok/renewlicense' , new LazyLoad($app , null , 'Licensing_RenewLicense'))->name('licensingRenewLicense') ;
$app->post('/licensing/:tok/fetchlicensedate' , new LazyLoad($app , null , 'Licensing_FetchLicenseDate'))->name('licensingFetchLicenseDate') ;
$app->post('/licensing/:tok/managefeatures' , new LazyLoad($app , null , 'Licensing_ManageFeatures'))->name('licensingManageFeatures') ;
$app->post('/licensing/:tok/updatenameaddress' , new LazyLoad($app , null , 'Licensing_UpdateNameAddress'))->name('updatenameaddress') ;
$app->post('/note'                          , new LazyLoad($app , 'src/note.php' , 'Note'))->name('takenote') ;

/*-------------------------------------------------------*
 *--  timeclock
 *-------------------------------------------------------*/
$app->post('/timeclock/:tok/logtime'                                         , new LazyLoad($app , null , 'Timeclock_LogTime'))->name('logtime') ;
$app->get('/timeclock/:tok/users'                                            , new LazyLoad($app , null , 'Timeclock_GetUsers'))->name('tcgetusers') ;
$app->get('/timeclock/:tok/getusertime/:name'                                , new LazyLoad($app , null , 'Timeclock_GetUserTime'))->name('getusertime') ;

$app->post('/timeclock/:tok/:merchtoken/updatetimelog'                       , new LazyLoad($app , null , 'Timeclock_UpdateTimelog'))->name('UpdateTimelog') ;
$app->get('/timeclock/:tok/:merchtoken/lasttimelog/:name'                    , new LazyLoad($app , null , 'Timeclock_LastTimelog'))->name('LastTimelog') ;
$app->get('/timeclock/:tok/:merchtoken/usertimelog/:name/:limit'             , new LazyLoad($app , null , 'Timeclock_UserTimelog'))->name('UserTimelog') ;

/*-------------------------------------------------------*
 *--  merchant messages
 *-------------------------------------------------------*/
$app->get   ('/merchmsgs/:tok'                                                           , new LazyLoad($app , 'src/merchantmsgs.php'    , 'MerchantMsgs_FetchMerchMsgs'))       ->name('fetchmerchmsgs') ;
$app->get   ('/merchmsgs/fetchmerchmsgs/tofile'                                          , new LazyLoad($app , ''                        , 'MerchMsgs_FetchMerchMsgsFile'))      ->name('fetchmerchmsgsfile') ;

/*-------------------------------------------------------*
 *--  configuration
 *-------------------------------------------------------*/
$app->get   ('/oneclicks/:tok/all'                                                       , new LazyLoad($app , ''                        , 'OneClicks_FetchAll'))                ->name('getoneclicks') ;
$app->post  ('/oneclicks/:tok/fetchdetail'                                               , new LazyLoad($app , ''                        , 'OneClicks_FetchDetail'))             ->name('getsingleoneclicks') ;
$app->post  ('/oneclicks/:tok/addupdate/:updateflag'                                     , new LazyLoad($app , ''                        , 'OneClicks_AddUpdate'))               ->name('addupdateoneclicks') ;
$app->post  ('/oneclicks/:tok/deletepage'                                                , new LazyLoad($app , ''                        , 'OneClicks_DeletePage'))              ->name('deleteoneclickpage') ;
$app->post  ('/oneclicks/:tok/addupdatepage/:updateflag'                                 , new LazyLoad($app , ''                        , 'OneClicks_AddUpdatePage'))           ->name('addupdateoneclickpage') ;
$app->post  ('/oneclicks/:tok/delete'                                                    , new LazyLoad($app , ''                        , 'OneClicks_Delete'))                  ->name('deleteoneclicks') ;
$app->post  ('/oneclicks/:tok/reposition'                                                , new LazyLoad($app , ''                        , 'OneClicks_Reposition'))                  ->name('oneclicks_reposition') ;

/*-------------------------------------------------------*
 *--  Boss Rev functions
 *-------------------------------------------------------*/
$app->get   ('/bossrev/:tok/query/:brnumber'                                             , new LazyLoad($app , 'src/br_funcs.php'        , 'BR_Query'))                          ->name('brquery') ;
$app->get   ('/bossrev/:tok/create/:brnumber(/:silent)'                                  , new LazyLoad($app , 'src/br_funcs.php'        , 'BR_Create'))                         ->name('brcreate') ;
//$app->get ('/bossrev/:tok/recharge/:brnumber/:amount/:hexname/:agentid'                , new LazyLoad($app , 'src/br_funcs.php'        , 'BR_Recharge'))                       ->name('brrecharge') ;
$app->get   ('/bossrev/:tok/rechargev2/:brnumber/:amount/:hexname/:agentid(/:promocode)' , new LazyLoad($app , 'src/br_funcs.php'        , 'BR_Rechargev2'))                     ->name('brrechargev2') ;
$app->get   ('/bossrev/:tok/merchquery'                                                  , new LazyLoad($app , 'src/br_funcs.php'        , 'BR_MerchQuery'))                     ->name('brmerchquery') ;
$app->get   ('/bossrev/:tok/asyncmerchquery'                                             , new LazyLoad($app , 'src/br_funcs.php'        , 'BR_AsyncMerchQuery'))                ->name('brasyncmerchquery') ;
/* FOB stuff */
$app->get   ('/brclub/:tok/checkfob/:fobid'                                              , new LazyLoad($app , 'src/br_funcs.php'        , 'BR_Check_Fob'))                      ->name('brcheckfob') ;
$app->get   ('/brclub/:tok/addfob/:fobid/:bracct'                                        , new LazyLoad($app , 'src/br_funcs.php'        , 'BR_Add_Fob'))                        ->name('braddfob') ;
$app->get   ('/brclub/:tok/updfob/:fobid/:bracct'                                        , new LazyLoad($app , 'src/br_funcs.php'        , 'BR_Upd_Fob'))                        ->name('brupdfob') ;
$app->get   ('/brclub/:tok/rmfob/:fobid'                                                 , new LazyLoad($app , 'src/br_funcs.php'        , 'BR_Rm_Fob'))                         ->name('brrmfob') ;
$app->get   ('/bossrev/:tok/reverse/:brnumber/:brtransid'                                 , new LazyLoad($app , 'src/br_funcs.php'        , 'BR_Reverse'))                         ->name('brreverse') ;
$app->get   ('/br_club/:tok/:merchtoken/:storeid/:brtoken'                               , new LazyLoad($app , 'src/brclub/get_brclub_by_token.php', 'BR_Token'))                ->name('brtoken') ;
/*-------------------------------------------------------*
 *--  Department Management
 *-------------------------------------------------------*/
$app->post  ('/depts/:tok/post'                                                          , new LazyLoad($app , ''                        , 'Departments_PostDepartment'))        ->name('deptpost') ;
$app->post  ('/depts/:tok/del'                                                           , new LazyLoad($app , ''                        , 'Departments_DeleteDepartment'))      ->name('deptartmentsdel') ;
$app->post  ('/depts/:tok/mov'                                                           , new LazyLoad($app , ''                        , 'Departments_MoveDepartment'))        ->name('deptsmov') ;
// depreciated
$app->post  ('/depts/:tok/add'                                                           , new LazyLoad($app , 'src/departments.php'     , 'Depts_add'))                         ->name('deptsadd') ;
$app->post  ('/depts/:tok/upd'                                                           , new LazyLoad($app , 'src/departments.php'     , 'Depts_upd'))                         ->name('deptsupd') ;

/*-------------------------------------------------------*
 * JUUL Products
 *-------------------------------------------------------*/
$app->get   ('/racs/:tok/juulproducts'                                                    , new LazyLoad($app , ''                        , 'Racs_JuulProducts'))                ->name('juulproducts') ;
$app->get   ('/racs/:tok/fetchjuulproducts'                                               , new LazyLoad($app , ''                        , 'Racs_FetchJuulProducts'))           ->name('fetchjuulproducts') ;

/*-------------------------------------------------------*
 * Gas Pumps
 *-------------------------------------------------------*/
$app->get    ('/pumps/:tok/'                                                              , new LazyLoad($app , ''                        , 'Pumps_FetchPumps'))                 ->name('fetchpumps') ;
$app->get    ('/pumps/:tok/currentprices'                                                 , new LazyLoad($app , ''                        , 'Pumps_CurrentPrices'))              ->name('currentprices') ;
$app->post   ('/pumps/:tok/fuelsale/:operation'                                           , new LazyLoad($app , ''                        , 'Pumps_FuelSale'))                   ->name('fuelsale') ;
$app->post   ('/pumps/:tok/transferfuel'                                                  , new LazyLoad($app , ''                        , 'Pumps_TransferFuel'))               ->name('transferfuel') ;
$app->get    ('/pumps/:tok/fuelsale/:ecrid'                                               , new LazyLoad($app , ''                        , 'Pumps_CCTransaction'))              ->name('cctransaction');
$app->post   ('/pumps/:tok/forecourtconfig'                                               , new LazyLoad($app , ''                        , 'Pumps_ForecourtConfig'))            ->name('forecourtconfig');
$app->post   ('/pumps/:tok/changeprices'                                                  , new LazyLoad($app , ''                        , 'Pumps_ChangePrices'))               ->name('changefuelprices');
$app->get    ('/pumps/:tok/report(/:drange)'                                              , new LazyLoad($app , ''                        , 'Pumps_FuelReport'))                 ->name('fuelreport');
$app->get    ('/pumps/:tok/transactions(/:drange)'                                        , new LazyLoad($app , ''                        , 'Pumps_FuelTransactions'))           ->name('fueltransactions');
$app->get    ('/pumps/:tok/report/print/:printfp/:drange(/:queue)'                        , new LazyLoad($app , ''                        , 'Pumps_PrintFuelReport'))            ->name('printfuelreport') ;
$app->get    ('/pumps/:tok/receipts/:deviceid'                                            , new LazyLoad($app , ''                        , 'Pumps_FuelReceipts'))               ->name('fuelreceipts');
$app->post   ('/pumps/:tok/receipt(/:queue)'                                              , new LazyLoad($app , ''                        , 'Pumps_PrintFuelReceipt'))           ->name('printfuelreceipt');
$app->post   ('/pumps/:tok/quickreceipt'                                                  , new LazyLoad($app , ''                        , 'Pumps_PrintQuickReceipt'))          ->name('printquickreceipt') ;
$app->post   ('/pumps/:tok/quickcreditreceipt'                                            , new LazyLoad($app , ''                        , 'Pumps_PrintQuickCreditReceipt'))    ->name('printquickcreditreceipt') ;
$app->post   ('/pumps/:tok/cancelfuelsale'                                                , new LazyLoad($app , ''                        , 'Pumps_CancelFuelSale'))             ->name('cancelfuelsale') ;
$app->get    ('/pumps/:tok/suspendfueling/:operation'                                     , new LazyLoad($app , ''                        , 'Pumps_SuspendFueling'))             ->name('suspendfueling') ;
$app->post   ('/pumps/:tok/postpay'                                                       , new LazyLoad($app , ''                        , 'Pumps_SendPostpayToCloud'))         ->name('sendpostpaytocloud') ;
$app->post   ('/pumps/:tok/alertpostauthfail'                                             , new LazyLoad($app , ''                        , 'Pumps_AlertPostAuthFail'))          ->name('alertpostauthfail') ;

/*-------------------------------------------------------*
 * MyBud
 *-------------------------------------------------------*/
$app->get   ('/pbitems/:tok/:pbname/packagelabel/:packagelabel'                           , new LazyLoad($app , ''                        , 'Pricebook_FetchPricebookItemByPackage')) ->name('fetchpbibypackage') ;
$app->post  ('/mybud/package/:tok/:operation'                                             , new LazyLoad($app , ''                        , 'MyBud_PostPackage'))                     ->name('postpackage') ;
$app->post  ('/mybud/:tok/updatelastid'                                                   , new LazyLoad($app , ''                        , 'MyBud_UpdateLastID'))                    ->name('updatelastid') ;
$app->get   ('/mybud/:tok/verifylicense/:state/:licenseid'                                , new LazyLoad($app , ''                        , 'MyBud_VerifyLicense'))                   ->name('verifylicense');
$app->get   ('/mybud/:tok/synchronizepackages'                                            , new LazyLoad($app , ''                        , 'MyBud_SynchronizePackages'))             ->name('synchronizepackages');
$app->post  ('/mybud/:tok/config'                                                         , new LazyLoad($app , ''                        , 'MyBud_Config'))                          ->name('mybudconfig');
$app->post  ('/mybud/:tok/recordsale'                                                     , new LazyLoad($app , ''                        , 'MyBud_RecordSale'))                      ->name('recordsale');
$app->get   ('/mybud/:tok/getucpuser/:cellphone'                                          , new LazyLoad($app , ''                        , 'MyBud_GetUCPUser'))                      ->name('getucpuser');
$app->post  ('/mybud/:tok/saveucpuser/:cellphone'                                         , new LazyLoad($app , ''                        , 'MyBud_SaveUCPUser'))                     ->name('saveucpuser');

//api call to papi
//$app->get    ('/merchportal/:tok/fuel/:merchtoken/sales/:storeid(/:drange)'               , new LazyLoad($app , ''                        , 'Pumps_FetchFuelSales'))             ->name('fetchfuelsales') ;
//$app->get    ('/merchportal/:tok/fuel/:merchtoken/printsales/:storeid/:printfp/:drange(/:queue)'   , new LazyLoad($app , ''                        , 'Pumps_PrintFuelSales'))             ->name('printfuelsales') ;

/*-------------------------------------------------------*
 *--  Revenue Authorities
 *-------------------------------------------------------*/
$app->get   ('/revauths/:tok'                                                            , new LazyLoad($app , ''                        , 'RevAuths_Fetch'))                    ->name('revauthsfetch') ;
$app->POST  ('/revauths/:tok/add'                                                        , new LazyLoad($app , ''                        , 'RevAuths_Add'))                      ->name('revauthadd') ;
$app->POST  ('/revauths/:tok/update'                                                     , new LazyLoad($app , ''                        , 'RevAuths_Update'))                   ->name('revauthupdate') ;
$app->POST  ('/revauths/:tok/delete'                                                     , new LazyLoad($app , ''                        , 'RevAuths_Delete'))                   ->name('revauthdelete') ;
$app->POST  ('/revauths/:tok/post'                                                       , new LazyLoad($app , ''                        , 'RevAuths_Post'))                      ->name('revauthpost') ;

/*-------------------------------------------------------*
 *--  system-ish things
 *-------------------------------------------------------*/
$app->get   ('/sys/adminreset'                                                           , new LazyLoad($app , 'src/diag.php'            , 'SYS_ResetAdmin'))                    ->name('sysresetadmin') ;
$app->get   ('/sys/localconfig'                                                          , new LocalConfig($app))                                                                 ->name('localconfig') ;
/*-------------------------------------------------------*
 *--  request callback extended; request paper refill
 *-------------------------------------------------------*/
$app->post  ('/tools/requestcallbackext/:tok'                                            , new LazyLoad($app , 'src/diag.php'            , 'RequestCallBackExt'))                ->name('requestcallbackext') ;
$app->post  ('/tools/requestpaperrefill/:tok'                                            , new LazyLoad($app , 'src/diag.php'            , 'PaperRefillRequest'))                ->name('requestpaperrefill') ;
$app->post  ('/tools/reqrefillfob/:tok'                                                  , new LazyLoad($app , 'src/diag.php'            , 'RequestRefillFob'))                  ->name('reqrefillfob') ;
$app->get   ('/tools/:tok/receiptfooter'                                                 , new LazyLoad($app , ''                        , 'Receipt_fetchfooter'))                  ->name('receiptfetchfooter') ;
$app->post  ('/tools/:tok/receiptfooter/save'                                            , new LazyLoad($app , ''                        , 'Receipt_Savefooter'))                  ->name('receiptsavefooter') ;

/*-------------------------------------------------------*
 *--  miscellaneous
 *-------------------------------------------------------*/
// ...nuke all sales/drop/payout info (feel free to question the wisdom of this)
$app->get   ('/sysdata/:tok/clear'                                                       , new LazyLoad($app , 'src/cashdrawer.php'      , 'Sysdata_Clear'))                     ->name('clearsysdata') ;

// ...open the cash drawer
$app->get('/cashdrawer/:tok/kick', new LazyLoad($app, 'src/cashdrawer.php', 'CD_Kick'))->name('kickcashdrawer') ;
$app->get('/cashdrawer/:tok/kick/silent', new LazyLoad($app, 'src/cashdrawer.php', 'CD_KickSilent'))->name('silentkickcashdrawer') ;
$app->get('/cashdrawer/:tok/getstatus/:simflag', new LazyLoad($app, 'src/cashdrawer.php', 'CD_Status'))->name('cashdrawerstatus') ;
$app->get('/cashdrawer/:tok/close', new LazyLoad($app, 'src/cashdrawer.php', 'CD_Close'))->name('cashdrawerclose') ;

// .. do update and restart
$app->get   ('/updaterestart'                                                            , new LazyLoad($app , 'src/updaterestart.php'   , 'updateRestart'))                     ->name('updaterestart') ;

// ...open the BOSS Revolution Retailer's Portal window
$app->get   ('/bossrevportal/:tok/open/:cashier'                                         , new LazyLoad($app , 'src/bossrev.php'         , 'BR_OpenRetailerPortal'))             ->name('openbossrevportal') ;
// ...open the BOSS Revolution Retailer's SSO Portal window
$app->get   ('/bossrevtoken/:tok'                                                        , new LazyLoad($app , 'src/bossrev.php'         , 'BR_getToken'))                      ->name('brgettoken') ;
$app->get   ('/bossrevssoportal/:tok/open/:cashier/:agent/:ssotoken/:url'                , new LazyLoad($app , 'src/bossrev.php'         , 'BR_OpenRetailerSSOPortal'))          ->name('openbossrevssoportal') ;
$app->get   ('/bossrevtransactions/:tok/:session'                                        , new LazyLoad($app , 'src/bossrev.php'         , 'BR_getTransactions'))               ->name('brgettransactions') ;

// ...open the BOSS Revolution Retailer's Training and help window
$app->get   ('/bossrevportal/:tok/training'                                              , new LazyLoad($app , 'src/bossrev.php'         , 'BR_OpenTrainingPortal'))             ->name('opentrainingportal') ;

$app->get   ('/store/:tok/fetchstatesandtz'                                              , new LazyLoad($app , ''                        , 'Store_FetchStatesAndTZ'))            ->name('fetchstatesandtz') ;
$app->post  ('/store/:tok/update'                                                        , new LazyLoad($app , ''                        , 'Store_Update'))                      ->name('updatestore') ;


/* diagnostics */

$app->get   ('/diag/shtest/:tname'                                                       , new LazyLoad($app , 'src/diag.php'            , 'ShTest'))                            ->name('shtest') ;
$app->get   ('/restartpos'                                                               , new LazyLoad($app , 'src/updaterestart.php'   , 'RestartPos'))                        ->name('restartpos') ;
$app->get   ('/powerdown'                                                                , new LazyLoad($app , 'src/power.php'           , 'PowerDown'))                         ->name('powerdown') ;
$app->get   ('/reboot'                                                                   , new LazyLoad($app , 'src/power.php'           , 'Reboot'))                            ->name('reboot') ;
$app->get   ('/posupdate'                                                                , new LazyLoad($app , 'src/diag.php'            , 'PosUpdate'))                         ->name('posupdate') ;
$app->get   ('/canpostponeupdate'                                                        , new LazyLoad($app , 'src/diag.php'            , 'CanPostponeUpdate'))                 ->name('canpostponeupdate') ;
$app->get   ('/postponeupdate'                                                           , new LazyLoad($app , 'src/diag.php'            , 'PostponeUpdate'))                    ->name('postponeupdate') ;
$app->get   ('/updatestatus'                                                             , new LazyLoad($app , 'src/diag.php'            , 'UpdateStatus'))                      ->name('updatestatus') ;
$app->get   ('/prnouttest'                                                               , new LazyLoad($app , ''                        , 'Print_PrintTest'))                   ->name('printtest') ;
$app->get   ('/queuecmd/:cmd'                                                            , new LazyLoad($app , 'src/diag.php'            , 'QueueCmd'))                          ->name('queuecmd') ;
$app->post  ('/queuecmddata/:cmd'                                                        , new LazyLoad($app , 'src/diag.php'            , 'QueueCmdData'))                          ->name('queuecmddata') ;
$app->get   ('/shouldupdate/:longidle'                                                   , new LazyLoad($app , 'src/diag.php'            , 'ShouldUpdate'))                      ->name('shouldupdate') ;
$app->get   ('/notifyupdatefailure'                                                      , new LazyLoad($app , 'src/diag.php'            , 'NotifyUpdateFailure'))               ->name('notifyupdatefailure') ;
$app->get   ('/diag/refreshdemo'                                                         , new LazyLoad($app,  'src/diag.php'            , 'RefreshDemo'))                       ->name('refresh_demo') ;

$app->get   ('/diag/chrome/:action'                                                     , new LazyLoad($app , 'src/diag.php'            , 'ChromeAction'))                      ->name('chrome_action') ;


/* Transaction History */
$app->get   ('/transactions/:tok/:drange'                                                , new LazyLoad($app , ''                        , 'History_Transaction'))               ->name('transactionhistory') ;

/* Authorizations and permissions */
$app->get   ('/permissions/:tok/fetchpermissions'                                        , new LazyLoad($app , ''                        , 'Authorize_FetchPerms'))              ->name('fetchperms') ;
$app->get   ('/permissions/:tok/fetchroles'                                              , new LazyLoad($app , ''                        , 'Authorize_FetchRoles'))              ->name('fetchroles') ;
$app->get   ('/permissions/:tok/fetchswitches'                                           , new LazyLoad($app , ''                        , 'Authorize_FetchSwitches'))           ->name('fetchswitches');
$app->get   ('/permissions/:tok/fetchnewvendormanagement'                                , new LazyLoad($app , ''                        , 'Authorize_FetchNewVendorManagement'))->name('fetchnewvendormanagement');

// api to call by extension to write file if it is loaded successfully
$app->get   ('/checkplugin/check'                                                        , new LazyLoad($app , ''                        , 'Plugin_Check'))                      ->name('checkpluginflag') ;
$app->get   ('/checkplugin/clear'                                                        , new LazyLoad($app , ''                        , 'Plugin_Clear'))                      ->name('clearpluginflag') ;
$app->get   ('/checkplugin/set'                                                          , new LazyLoad($app , ''                        , 'Plugin_Set'))                        ->name('setpluginflag') ;

//ewic
$app->get  ('/ewic/fetch_plu_list/:tok/:storeid(/:organic(/:searchquery))'                , new LazyLoad($app , 'src/ewic.php'            , 'EWIC_fetchAPLPLUs'))                 ->name('ewic_fetch_apl_plus') ;
$app->post  ('/ewic/query_apl/:tok'                                                       , new LazyLoad($app , 'src/ewic.php'            , 'EWIC_queryAPL'))                     ->name('ewic_query_apl') ;
$app->post  ('/ewic/print_balance/:tok/:storeid'                                          , new LazyLoad($app , 'src/ewic.php'            , 'EWIC_PrintBalance'))                 ->name('ewic_print_balance') ;
$app->post  ('/ewic/print_mid_receipt/:tok/:storeid'                                      , new LazyLoad($app , 'src/ewic.php'            , 'EWIC_PrintEwicReceipt'))             ->name('ewic_print_mid_receipt') ;
$app->post  ('/ewic/print_final_receipt/:tok/:storeid'                                    , new LazyLoad($app , 'src/ewic.php'            , 'EWIC_PrintEwicReceipt'))             ->name('ewic_print_final_receipt') ;
$app->post  ('/ewic/print_void_receipt/:tok/:storeid'                                     , new LazyLoad($app , 'src/ewic.php'            , 'EWIC_PrintVoidReceipt'))             ->name('print_void_receipt') ;

// credit card processing
//$app->get   ('/creditcard/:tok/charge/:amount/:ctype'                                    , new LazyLoad($app , ''                        , 'CreditCard_Chargebase'))                 ->name('cccharge') ;
$app->get   ('/creditcard/:tok/getpaxunit'                                               , new LazyLoad($app , ''                        , 'CreditCard_GetPaxUnit'))             ->name('getpaxunit') ;
$app->get   ('/creditcard/:tok/setpaxunit/:unit'                                         , new LazyLoad($app , ''                        , 'CreditCard_SetPaxUnit'))             ->name('setpaxunit') ;
$app->post  ('/creditcard/:tok/chargepost'						 , new LazyLoad($app , ''                        , 'CreditCard_Chargebase'))             ->name('ccpost') ;
$app->get   ('/creditcard/:tok/getdjconfig'                                              , new LazyLoad($app , ''                        , 'CreditCard_GetDjconfig'))            ->name('getdjconfig') ;
$app->post  ('/creditcard/:tok/request_confirmation'                                     , new LazyLoad($app , 'src/creditcard/paxcharge.class.php', 'PAX_RequestConfirmation')) ->name('pax_request_confirmation') ;
$app->get   ('/creditcard/:tok/getcashdiscount'                                          , new LazyLoad($app , ''                        , 'CreditCard_GetCashDiscount'))        ->name('getcashdiscount') ;
$app->get   ('/creditcard/getbatchconfiginfo'                                            , new LazyLoad($app , ''                        , 'CreditCard_GetBatchConfigInfo')) ->name('getbatchconfiginfo') ;
$app->post  ('/creditcard/:tok/batchout/:source'                                         , new LazyLoad($app , ''                        , 'CreditCard_BatchOut')) ->name('batchout') ;
$app->post  ('/creditcard/:tok/batchclear'                                               , new LazyLoad($app , ''                        , 'CreditCard_BatchClear')) ->name('batchclear') ;
$app->get  ('/creditcard/:tok/getvar/:var(/:edc_type)'                                   , new LazyLoad($app , ''                        , 'CreditCard_GetVar')) ->name('getvar') ;
$app->get  ('/creditcard/:tok/getlastbatch'                                              , new LazyLoad($app , ''                        , 'CreditCard_GetLastBatch')) ->name('getlastbatch') ;
$app->get  ('/creditcard/:tok/triggerbatchwarning'                                       , new LazyLoad($app , ''                        , 'CreditCard_TriggerBatchWarning')) ->name('triggerbatchwarning') ;

// adstats
$app->post  ('/adstats/addnew'                                                           , new LazyLoad($app , ''                        , 'AdStats_AddNew'))                    ->name('adstatsaddnew') ;
$app->get   ('/adstats/:tok/user/shown'                                                  , new LazyLoad($app , ''                        , 'AdStats_fetchShown'))                ->name('fetchshownads') ;
$app->POST  ('/adstats/:tok/user/shown/add'                                              , new LazyLoad($app , ''                        , 'AdStats_addShown'))                  ->name('addshownads') ;

/*-------------------------------------------------------*
 *--  email
 *-------------------------------------------------------*/
$app->post  ('/admin_email/register/:tok', new LazyLoad($app, '',  'Admin_Email'))->name('adminemailregister') ;
$app->post  ('/admin_email/update/:tok', new LazyLoad($app,'src/admin/email.class.php',  'Admin_Email'))->name('adminemailupdate') ;
$app->get   ('/admin_email/fetch/:tok', new LazyLoad($app,'src/admin/email.class.php',  'Admin_Email'))->name('adminemailfetch') ;
$app->post  ('/admin_email/link/:tok', new LazyLoad($app,'src/admin/email.class.php',  'Admin_Email'))->name('adminemaillink') ;
$app->post  ('/admin_email/get_verify_link/:tok', new LazyLoad($app,'src/admin/email.class.php',  'Admin_Email'))->name('adminemailgetlink') ;
//events
$app->post  ('/events/add/:tok'                                                          , new LazyLoad($app , ''   , 'Events_Add'))                        ->name('eventsadd') ;

//local scanning site functions
$app->get   ('/localwebgenpw'                                                            , new LazyLoad($app , ''                        , 'Scan_Genpw'))                        ->name('localwebgenpw') ;
$app->get   ('/localwebckpw/:pw'                                                         , new LazyLoad($app , ''                        , 'Scan_Ckpw'))                         ->name('localwebckpw') ;
$app->post  ('/storescan/:tok/add'                                                       , new LazyLoad($app , ''                        , 'Scan_Add'))                          ->name('addscanstore') ;
$app->get   ('/storescan/gettoken'                                                       , new LazyLoad($app , ''                        , 'Scan_DaemonToken'))                  ->name('daemontoken') ;
//verify ID License Scan
$app->get   ('/scan/:tok/idlicense'                                                      , new LazyLoad($app , ''                        , 'Scan_IDLicense'))                    ->name('idlicense') ;

$app->get('/merchportal/:tok/gettoken/:login', new LazyLoad($app , '' , 'MerchPortal_GetToken'))->name('merchportaltoken') ;
$app->get('/merchportal/:tok/inventory/:mertoken/:storeid/:disabled(/:loginid)', new LazyLoad($app , '', 'MerchPortal_openInventory'))->name('merchportalInventory') ;
$app->get('/merchportal/:tok/invgroup/:mertoken/:storeid', new LazyLoad($app , '', 'MerchPortal_inventoryInfo'))->name('inventoryGroup') ;
$app->post('/merchportal/:tok/inventory/:mertoken/setcount/:upc', new LazyLoad($app , '', 'MerchPortal_setInventory')) ->name('setInventoryInfo');
$app->get('/merchportal/:tok/inventory_getid/:mertoken/:storeid', new LazyLoad($app , '', 'MerchPortal_InventoryGetGroup'))->name('inventoryGetGroup') ;
$app->get('/merchportal/:tok/inventory_upcs/:mertoken/:storeid/groups/:group(/:upc)', new LazyLoad($app , '', 'MerchPortal_inventory'))->name('inventory') ;
$app->post('/merchportal/:tok/inventory_addstock/:mertoken/:storeid/groups/:group/upcs/:upc', new LazyLoad($app , '', 'MerchPortal_inventoryAddStock'))->name('inventoryAddStock') ;
$app->post('/merchportal/:tok/inventory_setcount/:mertoken/:storeid/groups/:group/upcs/:upc', new LazyLoad($app , '', 'MerchPortal_inventorySetCount'))->name('inventorySetCount') ;
$app->post('/merchportal/:tok/inventory_set/:mertoken/:storeid/groups/:group/upcs', new LazyLoad($app , '', 'MerchPortal_inventorySet'))->name('inventorySet') ;
$app->delete('/merchportal/:tok/inventory/:mertoken/:storeId/groups/:groupId/upcs/:upc', new LazyLoad($app , '', 'MerchPortal_deleteInventory')) ->name('stopInventoryTracking');
$app->post  ('/browse'                                                       , new LazyLoad($app , ''                        , 'Diag_Browse'))                          ->name('browse') ;

/*-------------------------------------------------------*
 *--  vendor managemnent
 *-------------------------------------------------------*/
$app->get('/merchportal/:tok/vendor/launch/:mertoken/:storeid/:is_admin(/:username)', new LazyLoad($app , '', 'MerchPortal_openVendor'))->name('merchportalVendor') ;
$app->get('/merchportal/:tok/vendor/url', new LazyLoad($app , '', 'MerchPortal_urlVendor'))->name('merchportalUrlVendor') ;


/*-------------------------------------------------------*
 *--  remote ads (just an initial configuration call ?)
 *-------------------------------------------------------*/
$app->get('/remoteads/bootstrap', new LazyLoad($app, '', 'RemoteAds_Bootstrap'))->name('ra_bootstrap') ;

/*-------------------------------------------------------*
 *--  crude volume control
 *-------------------------------------------------------*/
$app->get('/volume/get', new LazyLoad($app, '', 'Volume_Get'))->name('volume_get') ;
$app->get('/volume/set/:vol', new LazyLoad($app, '', 'Volume_Set'))->name('volume_set') ;
$app->get('/volume/up(/:amt)', new LazyLoad($app, '', 'Volume_Up'))->name('volume_up') ;
$app->get('/volume/down(/:amt)', new LazyLoad($app, '', 'Volume_Down'))->name('volume_down') ;

//External Orders
//tbd reformat

$app->get('/app_order/:tok/gettoken/:login', new LazyLoad($app , '', 'AppOrder_GetToken'))->name('appOrdergetToken') ;

$app->get('/app_order/:tok/launch', new LazyLoad($app , '', 'AppOrder_Open'))->name('appOrderOpen') ;
$app->get('/app_order/:tok/get_url', new LazyLoad($app , '', 'AppOrder_GetUrl'))->name('appOrderGetUrl') ;
$app->get('/app_order/:tok/fetchstatus', new LazyLoad($app , '', 'AppOrder_FetchStatus'))->name('appOrderFetchStatus') ;
$app->get('/app_order/:tok/fetchorders', new LazyLoad($app , '', 'AppOrder_Fetch'))->name('appOrderFetch') ;
$app->get('/app_order/:tok/fetchordersconfig', new LazyLoad($app , '', 'AppOrder_FetchOrdersConfig'))->name('appOrderFetchOrdersConfig') ;
$app->get('/app_order/:tok/fetchordercount'      , new LazyLoad($app , '' , 'AppOrder_FetchOrderCount'))      ->name('appOrderFetchOrderCount') ;
$app->post('/app_order/:tok/notifystatus', new LazyLoad($app , '', 'AppOrder_Notify'))->name('appOrderNotify') ;
$app->post('/app_order/:tok/chargepayment', new LazyLoad($app , '', 'AppOrder_ChargePayment'))->name('appOrderCharge') ;
$app->post('/app_order/:tok/notifybasketcomplete', new LazyLoad($app , '', 'AppOrder_NotifyBasketComplete'))->name('appOrderBasketComplete') ;
$app->post('/app_order/:tok/license_notify'      , new LazyLoad($app , '' , 'AppOrder_LicenseNotify'))      ->name('appOrderLicenseNotify') ;
/*-------------------------------------------------------*
 *--  customer tab calls
 *-------------------------------------------------------*/
$app->get('/app_customertab/:tok/launch',                                 new LazyLoad($app , '', 'AppCustomertab_Open'))->name('appCustomertabOpen') ;
$app->get('/app_customertab/:tok/fetchtransaction/:transaction_id',       new LazyLoad($app , '', 'AppCustomertab_FetchTransaction')) ->name('fetchtransaction') ;
$app->post('/app_customertab/:tok/posttransaction/:transaction_id',       new LazyLoad($app , '', 'AppCustomertab_PostTransaction'))  ->name('posttransaction') ;

$app->get('/app_customertab/:tok/fetchmapiurl',                           new LazyLoad($app , '', 'AppCustomertab_fetchMapiurl')) ->name('fetchmapiurl') ;

// general print function for printing BR receipts
$app->post('/printobj/:tok', new LazyLoad($app , '', 'Print_PrintObj'))->name('print_printobj') ;
$app->post('/print/:tok', new LazyLoad($app , '', 'Print_Print'))->name('print_print') ;
$app->post('/keylog/:tok', new LazyLoad($app , '', 'Diag_Keylog'))->name('diag_keylog') ;
$app->post('/jslog', new LazyLoad($app , '', 'Diag_Jslog'))->name('diag_jslog') ;

$app->post('/dvrwrite/:tok', new LazyLoad($app , '', 'Dvr_Write'))->name('dvr_write') ;

/*-------------------------------------------------------*
 *--  get/set max scale weight
 *-------------------------------------------------------*/
$app->get   ('/scale/getmax'                                                           , new LazyLoad($app , ''                               , 'Scale_Getmax'))                    ->name('scalegetmax') ;
$app->get   ('/scale/setmax/:max'                                                      , new LazyLoad($app,''                              , 'Scale_Setmax'))                    ->name('scalesetmax') ;

/*-------------------------------------------------------*
 *--  alarm
 *-------------------------------------------------------*/
$app->get('/alarm/:tok/activated', new LazyLoad($app , '', 'Alarm_Activated'))->name('alarmactivated') ;
$app->post('/alarm/:tok/log', new LazyLoad($app , '', 'Alarm_Log'))->name('alarmlog') ;
$app-> get ('/:tok/daily_summarize/:drange', new LazyLoad($app, 'src/daily_summarize.class.php', 'Daily_Summarize'))->name('dailysummarize');
$app->get('/stores/:tok/summarize_stats', new LazyLoad($app, '','Store_SummarizeStats'))->name('getsummarizestats');

/*-------------------------------------------------------*
 *--  held baskets
 *-------------------------------------------------------*/
$app->get('/held_basket',                                     new LazyLoad($app, '', 'HeldBaskets_List'))->name('listheldbaskets');
$app->post('/held_basket/:basketid',                          new LazyLoad($app, '', 'HeldBaskets_Post'))->name('postheldbasket');
$app->delete('/held_basket',                                  new LazyLoad($app, '', 'HeldBaskets_Clear'))->name('clearheldbasket');
$app->delete('/:tok/held_basket/:elmerid/:basketid',          new LazyLoad($app, '', 'HeldBaskets_Fetch'))->name('fetchheldbasket');

/*-------------------------------------------------------*
 *--  payment types
 *-------------------------------------------------------*/
$app->get('/:tok/paytypes/types', new LazyLoad($app , '', 'Paytypes_TypesList'))->name('paytypes_listtypes');
$app->get('/:tok/paytypes/buttons', new LazyLoad($app , '', 'Paytypes_ButtonsList'))->name('paytypes_listbuttons');
$app->post('/:tok/paytypes/buttonreset', new LazyLoad($app , '', 'Paytypes_ButtonReset'))->name('paytypes_resetbutton');
$app->post('/:tok/paytypes/types', new LazyLoad($app , '', 'Paytypes_TypePost'))->name('paytypes_posttype');
$app->post('/:tok/paytypes/button', new LazyLoad($app , '', 'Paytypes_ButtonPost'))->name('paytypes_postbutton');

/*-------------------------------------------------------*
 *--  e2e helpers
 *-------------------------------------------------------*/
$app->post('/e2ehelpers/clearbaskets', new LazyLoad($app , '', 'E2ehelpers_ClearBaskets'))->name('clearbaskets') ;
$app->post('/e2ehelpers/createitem', new LazyLoad($app , '', 'E2ehelpers_CreateItem'))->name('createitem') ;
$app->get('/e2ehelpers/getallupcs', new LazyLoad($app , '', 'E2ehelpers_GetAllUPCs'))->name('getallupcs') ;
$app->get('/e2ehelpers/getworkdayoffset', new LazyLoad($app , '', 'E2ehelpers_GetWorkdayOffset'))->name('getworkdayoffset') ;
$app->post('/e2ehelpers/setlastbasketdate/:date', new LazyLoad($app , '', 'E2ehelpers_SetLastBasketDate'))->name('setlastbasketdate') ;
$app->post('/e2ehelpers/setlastsessiondate/:date', new LazyLoad($app , '', 'E2ehelpers_SetLastSessionDate'))->name('setlastsessiondate') ;



$app->run() ;

// ...audit log (except inconsequantial)
//error_log(__METHOD__.json_encode((array)$app->router->getCurrentRoute()));
$currRouteName = $app->router->getCurrentRoute()->getName() ;
if( ! empty($currRouteName)
    &&
    ! in_array( $currRouteName
               ,[
                  'getadconfig'
                 ,'fetchshownads'
                 ,'addshownads'
                 ,'adstatsaddnew'
                 ,'authenticate'
                 ,'passwordauth'
                 ,'genupca'
                 #,'updatebasketitem'
                 #,'voidbasketitem'
                 #,'addtobasket'
                 #,'basketbossquery'
                 #,'closebasket'
                 #,'multiaddtobasket'
                 #,'pausebasket'
                 ,'printbasket'
                 #,'renderbasket'
                 #,'resumebasket'
                 #,'basketsetloyalty'
                 #,'getbaskets'
                 ,'getsessionbaskets'
                 ,'brquery'
                 ,'brmerchquery'
                 ,'openbossrevportal'
                 ,'opentrainingportal'
                 ,'brcheckfob'
                 ,'browse'
                 ,'fetchlastitem'
                 ,'postlastitem'
                 ,'kickcashdrawer'
                 ,'silentkickcashdrawer'
                 ,'cashdrawerstatus'
                 ,'checkpluginflag'
                 ,'clearpluginflag'
                 ,'setpluginflag'
                 ,'getdjconfig'
                 ,'getcashdiscount'
                 ,'getpaxunit'
                 ,'setpaxunit'
                 ,'customerLastPurchase'
                 ,'departments'
                 ,'shtest'
                 ,'printdrop'
                 ,'getdrops'
                 #,'createdrop'
                 ,'getsessiondrops'
                 ,'eventsadd'
                 ,'licensingCheckLicense'
                 ,'licensingFetchLicenseDate'
                 ,'licensingManageFeatures'
                 ,'updatenameaddress'
                 ,'note'
                 ,'LicensingRenewLicense'
                 ,'logins'
                 ,'fetchstorelogo'
                 ,'fetchmerchmsgs'
                 ,'fetchmerchmsgsfile'
                 ,'inventory'
                 ,'fetchmasteritem'
                 ,'fetchprivateitems'
                 ,'getoneclicks'
                 ,'termsyncpoke'
                 ,'fetchlistpbis'
                 ,'summarizestats'
                 ,'fetchpbi'
                 ,'fetchpbibypackage'
                 ,'postpackage'
                 ,'fetchlesspbis'
                 ,'fetchmasterpbitem'
                 ,'fetchprivatepbis'
                 ,'fetchperms'
                 ,'fetchroles'
                 ,'ping'
                 ,'fetchpbitems'
                 ,'fetchpbitem'
                 ,'lessfieldpbitem'
                 ,'printtest'
                 ,'checkinexistingpromotion'
                 ,'currentpromos'
                 ,'countpromos'
                 ,'fetchpromodetail'
                 ,'fetchcloudpromousage'
                 ,'fetchlocalpromousage'
                 ,'fetchexternalpromos'
                 ,'ra_bootstrap'
                 ,'revauthsfetch'
                 ,'rewardsCheck'
                 ,'rewardsConvey'
                 ,'rewardsNotifyPrint'
                 #,'cashin'
                 #,'close'
                 ,'fetchsessionrange'
                 ,'fectsessions'
                 ,'getsessionstats'
                 ,'getsessionsummary'
                 ,'getlastunclosedsession'
                 ,'shouldupdate'
                 ,'fetchstatesandtz'
                 ,'getstoreinfo'
                 ,'getterminalinfo'
                 ,'printstoreshiftstats'
                 ,'printstorestats'
                 ,'printstorecardstats'
                 ,'getstorestats'
                 ,'getstorecardstats'
                 ,'addscanstore'
                 ,'getsyncstatus'
                 ,'fetchchangeset'
                 ,'receiptfetchfooter'
                 ,'transactionhistory'
                 ,'fetchupcsupdates'
                 ,'fetchDetail'
                 ,'getusers'
                 ,'getcuruser'
                 ,'validate'
                 ,'fetchvendorpayouts'
                 ,'getvendors'
                 ,'fetchVendorPayoutsWithDateRange'
                 ,'printvendordetail'
                 ,'diag_keylog'
                 ,'idlicense'
                 ,'juulproducts'
                 ,'fetchpumps'
                 ,'currentprices'
                 ,'fuelsale'
                 ,'transferfuel'
                 ,'cctransaction'
                 ,'forecourtconfig'
                 ,'mybudconfig'
                 ,'synchronizepackages'
                 ,'recordsale'
                 ,'getucpuser'
                 ,'saveucpuser'
                 ,'transferbasket'
                 ,'changefuelprices'
                 ,'fuelreport'
                 ,'fueltransactions'
                 ,'printfuelreport'
                 ,'fuelreceipts'
                 ,'updatelastid'
                 ,'verifylicense'
                 ,'printfuelreceipt'
                 ,'printquickreceipt'
                 ,'printquickcreditreceipt'
                 ,'sendpostpaytocloud'
                 ,'alertpostauthfail'
                 ,'cancelfuelsale'
                 ,'suspendfueling'
                 ,'fetchjuulproducts'
                 ,'refresh_demo'
                 ,'diag_jslog'
               ]
)){
  $app->getLog()->info(
    'AuditInfo: ' .
    str_replace('"{~REQUEST~}"', preg_replace(['~\\\\+"~', '~"([\\[\\{])~', '~([\\]\\}])"~'], ['"', '$1', '$1'], $app->request->getBody()) ?: 'null', json_encode(
      [
        'date'        => date("Y-m-d H:i:s")
        ,'routeInfo'  => [
          'routeName'  => $app->router->getCurrentRoute()->getName()
          ,"path"      => $app->request->getPathInfo()
          ,"method"    => $app->request->getMethod()
        ]
        #,'routeInfo' => $app->request->getResourceUri()
        ,'posted'     => '{~REQUEST~}'
        #,'debug'     => print_r($app->router->getCurrentRoute(),1)
      ]
      ,
      JSON_UNESCAPED_SLASHES
    ))
  ) ;

}
