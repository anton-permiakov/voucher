chrome.runtime.onMessage.addListener(
  function(request, sender, sendResponse) {
  	chrome.tabs.query({
		  	    active: true,               // Select active tabs
		  	    lastFocusedWindow: true     // In the current window
		  	}, function(array_of_Tabs) {
		  		tabs = array_of_Tabs;
          for(var t = tabs.length - 1; t >= 0; t--)
          {
            chrome.tabs.remove(tabs[t].id, function(){});
          }
  	});
  });

chrome.webNavigation.onErrorOccurred.addListener(function(details){
	if(details.frameId === 0) {
		chrome.tabs.update(details.tabId, {
			url: 'http://localhost/errors/index.html?error=' + encodeURIComponent(details.error)
		});
	}
});
